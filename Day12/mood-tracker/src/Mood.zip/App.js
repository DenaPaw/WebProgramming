import MoodTracker from "./MoodTracker";
import './App.css';

function App() {
  return (
    <div>
      <MoodTracker/>
    </div>
  );
}
export default App;